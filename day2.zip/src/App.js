import logo from './logo.svg';
import './App.css';

import Appbar from './components/Appbar';
import StateBasics from './components/StateBasics';
import Counter from './components/Counter';
import UseE from './components/UseE';
import Mapping from './components/Mapping';

function App() {
  return (
    <div className="App">
   {/* <Appbar/>
   <StateBasics/> */}
   {/* <Counter/> */}
   {/* <UseE/> */}
   <Mapping/>

    </div>
  );
}

export default App;
